document.addEventListener('DOMContentLoaded', function () {
  // Config state
  let config = {};

  // Elements
  const txtApiKey = document.getElementById('txt-api-key');
  const btnToggleKey = document.getElementById('btn-toggle-key');
  
  const rngDelay = document.getElementById('rng-delay');
  const valDelay = document.getElementById('val-delay');
  const chkSubmit = document.getElementById('chk-submit');
  
  const chkFuncaptcha = document.getElementById('chk-funcaptcha');
  const statusFuncaptcha = document.getElementById('status-funcaptcha');
  
  const chkHcaptcha = document.getElementById('chk-hcaptcha');
  const statusHcaptcha = document.getElementById('status-hcaptcha');
  
  const chkRecaptcha = document.getElementById('chk-recaptcha');
  const statusRecaptcha = document.getElementById('status-recaptcha');
  
  const chkTurnstile = document.getElementById('chk-turnstile');
  const statusTurnstile = document.getElementById('status-turnstile');
  
  const balanceVal = document.getElementById('balance-val');
  const solvedVal = document.getElementById('solved-val');
  const btnRefresh = document.getElementById('btn-refresh');

  // Load config from local storage
  chrome.storage.local.get(['config'], function (result) {
    if (result.config) {
      config = result.config;
      initUI();
      fetchBalance();
    } else {
      console.warn("SunCaptcha config not found in local storage.");
    }
  });

  // Initialize UI values from config
  function initUI() {
    // API key
    txtApiKey.value = config.clientKey || '';

    // Click speed (times)
    rngDelay.value = config.times || 200;
    valDelay.textContent = `${rngDelay.value}ms`;

    // Auto submit
    chkSubmit.checked = !!config.isAutoSubmit;

    // FunCaptcha status
    chkFuncaptcha.checked = !!(config.funcaptchaConfig && config.funcaptchaConfig.isOpen);
    updateToggleLabel(chkFuncaptcha, statusFuncaptcha);

    // hCaptcha status
    chkHcaptcha.checked = !!config.hcaptcha;
    updateToggleLabel(chkHcaptcha, statusHcaptcha);

    // reCaptcha status
    chkRecaptcha.checked = !!config.imageclassification;
    updateToggleLabel(chkRecaptcha, statusRecaptcha);

    // Turnstile status
    chkTurnstile.checked = !!config.isOpenCloudflareTurnstileProtocol;
    updateToggleLabel(chkTurnstile, statusTurnstile);
  }

  // Update text label next to switch toggle
  function updateToggleLabel(checkbox, label) {
    if (checkbox.checked) {
      label.textContent = 'ON';
      label.classList.add('active');
    } else {
      label.textContent = 'OFF';
      label.classList.remove('active');
    }
  }

  // Save config helper
  function saveConfig() {
    chrome.storage.local.set({ config }, function () {
      console.log('SunCaptcha config saved.');
    });
  }

  // Fetch balance from API
  function fetchBalance() {
    if (!config.clientKey || !config.host) {
      balanceVal.textContent = '$0.00';
      solvedVal.textContent = '0';
      return;
    }

    btnRefresh.classList.add('spinning');
    
    // API url
    const balanceUrl = `${config.host}getBalance`;
    
    fetch(balanceUrl, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        clientKey: config.clientKey
      })
    })
    .then(response => {
      if (!response.ok) throw new Error('Network response not ok');
      return response.json();
    })
    .then(data => {
      btnRefresh.classList.remove('spinning');
      if (data && data.errorId === 0) {
        const bal = parseFloat(data.balance || 0);
        balanceVal.textContent = `$${bal.toFixed(2)}`;
        solvedVal.textContent = parseInt(data.total_solves || 0).toLocaleString();
      } else {
        console.error('API Error:', data);
        balanceVal.textContent = 'Error';
      }
    })
    .catch(err => {
      btnRefresh.classList.remove('spinning');
      console.error('Fetch balance error:', err);
      balanceVal.textContent = 'Offline';
    });
  }

  // EVENT LISTENERS

  // Visibility toggle for API Key
  btnToggleKey.addEventListener('click', function () {
    if (txtApiKey.type === 'password') {
      txtApiKey.type = 'text';
      btnToggleKey.style.color = '#FF7E40';
    } else {
      txtApiKey.type = 'password';
      btnToggleKey.style.color = '#6B7280';
    }
  });

  // API Key input change
  txtApiKey.addEventListener('change', function () {
    config.clientKey = txtApiKey.value.trim();
    saveConfig();
    fetchBalance();
  });

  // Delay slider change
  rngDelay.addEventListener('input', function () {
    valDelay.textContent = `${rngDelay.value}ms`;
    config.times = parseInt(rngDelay.value, 10);
  });
  
  rngDelay.addEventListener('change', function () {
    saveConfig();
  });

  // Auto submit change
  chkSubmit.addEventListener('change', function () {
    config.isAutoSubmit = chkSubmit.checked;
    saveConfig();
  });

  // Toggles change events
  chkFuncaptcha.addEventListener('change', function () {
    if (!config.funcaptchaConfig) config.funcaptchaConfig = {};
    config.funcaptchaConfig.isOpen = chkFuncaptcha.checked;
    updateToggleLabel(chkFuncaptcha, statusFuncaptcha);
    saveConfig();
  });

  chkHcaptcha.addEventListener('change', function () {
    config.hcaptcha = chkHcaptcha.checked;
    updateToggleLabel(chkHcaptcha, statusHcaptcha);
    saveConfig();
  });

  chkRecaptcha.addEventListener('change', function () {
    config.imageclassification = chkRecaptcha.checked;
    updateToggleLabel(chkRecaptcha, statusRecaptcha);
    saveConfig();
  });

  chkTurnstile.addEventListener('change', function () {
    config.isOpenCloudflareTurnstileProtocol = chkTurnstile.checked;
    updateToggleLabel(chkTurnstile, statusTurnstile);
    saveConfig();
  });

  // Refresh button click
  btnRefresh.addEventListener('click', function () {
    fetchBalance();
  });
});
