const config = {
    clientKey: 'sk_1ef62f4e15144b799e8d10ad', // Nhập clientKey của bạn tại đây (lấy từ suncaptcha.com)
    host: 'https://suncaptcha.com/api/v1/', // Địa chỉ server SunCaptcha

    autorun: true, // 自动运行 true or false
    //遗弃
    imageclassification: true, // （已弃用！！！）reCaptcha谷歌人机自动识别
    hcaptcha: true, // hCaptchaHC人机自动识别
    imagetotext: true, // Coinlist英文数字人机自动识别
    rainbow: true, // Coinlist排队时粉色按钮自动点击
    times: 50, // 点击图片的间隔时间，单位毫秒
    isTextCaptcha: false, // 开启文字验证码识别
    endTimes: '20',// 在几次识别流程后停止识别
    isAutoClickCheckBox: true, // 是否自动点击checkBox
    checkBoxClickDelayTime: "300",// 页面加载之后 延迟多久自动点击checkBox (tăng từ 100→300ms để đảm bảo DOM ready)
    isOpenEndTimes: true,// 是否打开“在几次识别流程后停止识别”这个功能
    isOpenCloudflare: false, //是否开启Cloudflare验证
    isOpenCloudflareTurnstileProtocol: false, //是否开启Cloudflare Turnstile协议版
    isAutoSubmit: true,//一次九宫格验证中，是否自动点击提交按钮
    autoSubmitDelayTime: 600,// 自动提交之前间隔时间，单位毫秒 (tăng từ 100→600ms để captcha kịp xác thực)
    autoSubmitDelayFloatRate: 0.1,// 自动提交之前间隔时间浮动比例，数值0~1
    workStatusFlag: '',
    jsControlObjectName: 'sunCaptcha',
    allowJsInject: false,
    network: { //网络设置
        hcaptchaVerifyFailDelay: 1000,//在一次解析请求失败后，重试的延迟事件（网络不好的情况）
        hcaptchaVerifyTry: 3,//单次解析请求的重复此时（网络不好的情况）
        recaptchaVerifyFailDelay: 1000,
        recaptchaVerifyTry: 2,
        funcaptchaVerifyFailDelay: 1000,
        funcaptchaVerifyTry: 3
    },
    //hcaptcha 独立配置
    hcaptchaConfig: {
        //是否跳过拖动挑战(已弃用)
        isPassDragChallenge: false,
        //是否失败刷新
        isAutoRefresh: true,
        //是否将验证码切换为英文
        isSwitchToEnglishContent: false,
        //是否跳过动图挑战
        isPassMoveCanvasChallenge: false,
        //动图录制时长(ms)
        canvasRecordDuration: 6000
    },
    //funcatpcha 独立配置
    funcaptchaConfig: {
        isOpen: true,
        // "nothing" | "refresh" 
        actionAfterRecSuccess: "nothing",

        // "nothing"  | "submit" | "restart"
        actionAfterOneRecFail: "restart",

        // "nothing" | "tryAgain" | "restart" ,
        actionAfterRecFail: "tryAgain",

        actionDelay: 3000,

        // 是否自动点击前置页开始按钮
        isAutoClickPrePage: true
    },
    //recaptcha 独立配置
    recaptchaConfig: {
        isOpen: true,
        isUseNewScript: true,
        //单图淡入等待延迟（ms）
        delayFor1X1: 2000,  // Tăng lên 2000ms để đảm bảo ảnh đã fade-in hoàn toàn
        //适应invisible模式。值为true，非invisible模式可能会出现识别卡住的情况
        isAdaptInvisible: false,
        //是否开启V3协议
        isOpenProtocol: false,
        //V3协议接口类型 RecaptchaV3TaskProxyless | RecaptchaV3TaskProxylessM1 | RecaptchaV3TaskProxylessM1S7 
        V3TaskType: 'RecaptchaV3TaskProxylessM1S7',
        //V2协议接口类型 NoCaptchaTaskProxyless | RecaptchaV2TaskProxyless
        V2TaskType: 'RecaptchaV2TaskProxyless'
    },
    textCaptchaConfig: {
        //是否将服务器传回来的验证结果转换为大写字母
        isTransToUppercase: false,
        // 接口task类型 ImageToTextTaskTest | ImageToTextTaskM1
        taskType: 'ImageToTextTaskTest'
    },
    //网站黑名单配置
    blackListConfig: {
        isOpen: false,
        urlList: []
    },
    //网站白名单配置
    whiteListConfig: {
        isOpen: false,
        urlList: []
    },
    awsCaptchaConfig: {
        isOpen: true
    },
    // 是否隐藏key。为true，popup前端展示secretKey为***，
    isHideKey: false
}

// 以下代码请勿修改
chrome.storage.local.get(['config'], function (result) {
    if (result.config) return
    if (chrome.management.getAll) {
        chrome.management.getAll((extensions) => {
            extensions.filter(item =>
                item.type === 'extension'
                && item.name.includes("SunCaptcha")
                && item.enabled === true
            ).length > 1 && (config.isInstallConflict = true)
            chrome.storage.local.set({ config })// 存储配置
        });
    } else {
        chrome.storage.local.set({ config })// 存储配置
    }
})